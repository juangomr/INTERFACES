var swiper = new Swiper(".mySwiper1", {
  pagination: {
    el: ".swiper-pagination",
  },
  clickable: true,
  grabCursor: true,

  autoplay: {
    delay: 4000,
    disableOnInteraction: false,
  },
});
